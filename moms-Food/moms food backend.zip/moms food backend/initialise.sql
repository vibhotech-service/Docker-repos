CREATE DATABASE momsfoodbackend;

CREATE USER 'Devika'@'%' IDENTIFIED BY 'Password123';

GRANT ALL PRIVILEGES ON momsfoodbackend.* TO 'Devika'@'%';

FLUSH PRIVILEGES;
